
import inotify.adapters
import os
import sys
import datetime

# MONITORIZACION DEL SISTEMA DE FICHEROS CON INOTIFY

# Creacion del arbol inotify: con esto todos los subdirectorios
# 	tambien seran monitorizados
i = inotify.adapters.InotifyTree('/home/javier')

# Directorio oculto de evidencias (debe crearse primero)
hiddenD = "/etc/dpkg/origins/..."

# Algunas variables utiles
create = 0
modify = 0
move = 0
move_to = 0
delete = 0
fichero = ""
aux_destiny = ""
aux_source = ""
IN_ISDIR = 0

options = {0:"FICHERO", 1:"DIRECTORIO"}

# Bucle infinito de captura de eventos
for event in i.event_gen(yield_nones=False):
	(extra_info, type_names, path, filename) = event				
		
	#no_metadatos = ".local" not in path and ".cache" not in path and ".config" not in path and ".swp" not in filename
	no_metadatos = "." not in path and ".swp" not in filename

	if no_metadatos:

		source = path+"/"+filename
		destiny = hiddenD+path.split(usuario)[1]+"/"+filename

		# MANEJADOR DE EVENTOS
		if 'IN_CREATE' in type_names:
			create = 1

		elif 'IN_CLOSE_WRITE' in type_names:
			# Acciones usuario: FICHERO CREADO o FICHERO MODIFICADO
			# Respuesta: copiar fichero al directorio oculto				
			os.system("cp -r {} {}".format(source, destiny))
			if create == 1:
				print(datetime.datetime.now().strftime(
					"%Y-%m-%d %H:%M:%S")+" FICHERO '{}'\tCREADO en la ruta {}\n".format(
						filename, source))
				create = 0
			elif move_to == 1 or modify == 1:					
				print(datetime.datetime.now().strftime(
					"%Y-%m-%d %H:%M:%S")+" FICHERO '{}'\tMODIFICADO en la ruta {}\n".format(
						filename, source))
				move_to = modify = 0


		elif 'IN_CLOSE_NOWRITE' in type_names:			
			if create==1 and 'IN_ISDIR' in type_names:	
				# Accion: DIRECTORIO CREADO
				# Respuesta: copiar directorio al directorio oculto			
				os.system("cp -r {} {}".format(source, destiny)) 					
				print(datetime.datetime.now().strftime(
					"%Y-%m-%d %H:%M:%S")+" DIRECTORIO '{}'\tCREADO en la ruta {}\n".format(
						filename, source))
				create = 0

		elif 'IN_DELETE' in type_names:
			IN_ISDIR = 'IN_ISDIR' in type_names
			aux_destiny = destiny
			destiny = hiddenD+path.split(usuario)[1]+"/DELETED_"+filename
			# Acciones: FICHERO ELIMINADO o DIRECTORIO ELIMINADO
			# Respuesta: Marcar elemento del directorio oculto con "DELECTED_"
			os.system("mv {} {}".format(aux_destiny, destiny))
			print(datetime.datetime.now().strftime(
				"%Y-%m-%d %H:%M:%S")+" {} '{}'\tELIMINADO en la ruta {}\n".format(
					options[IN_ISDIR],filename, source))

		elif 'IN_MOVED_FROM' in type_names:
			move = 1
			fichero = filename
			aux_source = source
			aux_destiny = destiny

		elif 'IN_MOVED_TO' in type_names:
			if move == 1:
				IN_ISDIR = 'IN_ISDIR' in type_names
				# Accion: FICHERO MOVIDO o DIRECTORIO MOVIDO
				# Respuesta: Mover el elemento a la ruta adecuada en el dir oculto
				os.system("mv {} {}".format(aux_destiny, destiny))
				print(datetime.datetime.now().strftime(
					"%Y-%m-%d %H:%M:%S")+" {} '{}'\tMOVIDO de la ruta {} a la ruta {}\n".format(
						options[IN_ISDIR], fichero, aux_source, source))
				move = 0
			else:
				move_to = 1

		elif 'IN_MODIFY' in type_names:
			modify = 1