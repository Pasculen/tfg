# socket-reading thread
def thread_job():

    import OpenSSL
    from OpenSSL.SSL import TLSv1_2_METHOD, FILETYPE_PEM, VERIFY_FAIL_IF_NO_PEER_CERT
    import socket
    from cryptography import x509
    from cryptography.hazmat.backends import default_backend
    from cryptography.hazmat.primitives import serialization

    def hola():
        pass

    # Create context for de TLS session
    context = OpenSSL.SSL.Context(TLSv1_2_METHOD)

    # Load server private key and cert
    context.use_privatekey_file(os.path.join(app.instance_path, "server_key.pem"))
    context.use_certificate_file(os.path.join(app.instance_path, "server_cert.pem"))

    # Add verify mode
    context.set_verify(VERIFY_FAIL_IF_NO_PEER_CERT, hola)

    # Load root certificate
    context.load_verify_locations(cafile=os.path.join(app.instance_path, "certificate.pem"))

    # Create the initial connection with the above context and a socket
    soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    soc.setblocking(1)
    soc.bind((HOST, PORT))
    soc.listen(1)
    conn_ini = OpenSSL.SSL.Connection(context, soc)

    
    # Accept client connection
    while 1:
        conn, addr = conn_ini.accept()
        conn.set_accept_state()
        print("Connected by "+str(addr))

        while 1:
            try:
                data = conn.read(1024)

                # Connect to the flask database
                conn_db = connect(os.path.join(app.instance_path, "flaskr.sqlite")) 
                curs = conn_db.cursor()
                evidencias = data.decode().split('\n')
                for e in evidencias:
                    if e != '' and "_rule" in e:
                        e = e.split('. ')[1]
                        e = "AUDITD: "+e
                    elif e != '':
                        e = "INOTIFY: "+e

                    if e != '':
                        curs.execute("INSERT INTO evidence (body) VALUES (?);",
                            [e],
                            )
                conn_db.commit()
                conn_db.close()
                #print(data.decode())
            except OpenSSL.SSL.SysCallError as e:
                #if e[0] == -1 or e[1] == 'Unexpected EOF':
                conn.shutdown()
                break

with app.app_context():
    t = AppContextThread(target=thread_job)
    t.start()
    #t.join()