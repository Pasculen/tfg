import os
import sys

# CONTROL ARGUMENTOS DE ENTRADA
if len(sys.argv) < 4 or sys.argv[2] != '-ip':
	print('Número de argumentos incorrecto.\n'
		'Sigue el siguiente esquema:'
			' ./auditd_config username -ip IP,PORT [-s kill,execve,etc] [--restart]')
	os._exit(0)

# Comprobar que usuario existe
usuario = sys.argv[1]
if not os.path.isdir('/home/'+usuario):
	print("El usuario '{}' NO existe. Prueba con otro.".format(usuario))
	os._exit(0)

# Gestion argumentos
ip_port = sys.argv[3].split(',')
HOST = ip_port[0]
PORT = int(ip_port[1])

# Ubicacion nuevo audit.log
audit_log = "/home/"+usuario+"/.audit.log"

#### CONFIGURACION AUDITD ####
os.system('systemctl stop auditd')
if os.path.isfile(audit.log):
	os.system('rm '+audit.log)

# Modificacion auditd.conf para cambiar log_file
with open('/etc/audit/auditd.conf', "w") as audit_conf:
	audit_conf.write ('#\n# This file controls the configuration of the audit daemon\n#\n'
		'local_events = yes\n'
		'write_logs = yes\n'
		'log_file = '+audit_log+'\n'
		'log_group = adm\n'
		'log_format = ENRICHED\n'
		'flush = INCREMENTAL_ASYNC\n'
		'freq = 50\n'
		'max_log_file = 8\n'
		'num_logs = 5\n'
		'priority_boost = 4\n'
		'disp_qos = lossy\n'
		'dispatcher = /sbin/audispd\n'
		'name_format = NONE\n'
		'##name = mydomain\n'
		'max_log_file_action = ROTATE\n'
		'space_left = 75\n'
		'space_left_action = SYSLOG\n'
		'verify_email = yes\n'
		'action_mail_acct = root\n'
		'admin_space_left = 50\n'
		'admin_space_left_action = SUSPEND\n'
		'disk_full_action = SUSPEND\n'
		'disk_error_action = SUSPEND\n'
		'use_libwrap = yes\n'
		'##tcp_listen_port = 60\n'
		'tcp_listen_queue = 5\n'
		'tcp_max_per_addr = 1\n'
		'##tcp_client_ports = 1024-65535\n'
		'tcp_client_max_idle = 0\n'
		'enable_krb5 = no\n'
		'krb5_principal = auditd\n'
		'##krb5_key_file = /etc/audit/audit.key\n'
		'distribute_network = no\n')

if not os.path.isfile(audit_log)
	os.system('touch '+audit_log)

# Inclusion de reglas de auditoria
with open('/etc/audit/rules.d/audit.rules', "w") as audit_rules:
	audit_rules.write('## First rule - delete all\n'
		'-D\n\n'
		'## Increase the buffers to survive stress events.\n'
		'## Make this bigger for busy systems\n'
		'-b 8192\n\n'
		'## This determine how long to wait in burst of events\n'
		'--backlog_wait_time 0\n\n'
		'## Set failure mode to syslog\n'
		'-f 1\n\n')
	syscalls = sys.argv[5].split(',')
	for s in syscalls:
		audit_rules.write('-a always,exit -F arch=b64 -S '+s+' -k '+s+'_rule -F uid='+usuario+'\n')

os.system('systemctl restart auditd')