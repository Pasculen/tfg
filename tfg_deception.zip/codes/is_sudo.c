/*
 * Detect if uid is 0
 */
static int is_sudo(){

    FILE* f = fopen("/etc/hola", "r");
    if(f == NULL) {
        return 0;
    }

    fclose(f);
    return 1;
}